// pages/About.jsx
import React from 'react'

const About = () => {
  return (
    <div className="about-page">
      <h1 className="page-title">关于我们</h1>
      <div className="container">
        <p>我们的咖啡故事始于2010年...</p>
        {/* 添加实际内容 */}
      </div>
    </div>
  )
}

export default About